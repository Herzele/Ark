
class Animals{
	constructor (params){

	this.aniName = params.aniName;
	this.aniFood = params.aniFood;
	this.aniSize = params.aniSize;
	this.aniAttract = params.aniAttract;
	this.aniCost = this.aniAttract * 1000;
	this.aniPlace = 'none';
	this.aniPlaceId = params.aniPlaceId;
	this.aniEncId = params.aniEncId;
	this.aniId = params.aniId;
	this.isInit = true;

	baseAnimalList.push(this);

	}

	getInstance(){
		let baseIdentifier = availableList.length;
		return baseIdentifier = new Animals({
			aniName: this.aniName,
			aniFood: this.aniFood,
			aniSize: this.aniSize,
			aniAttract: this.aniAttract,
			aniEncId: this.aniEncId,
			isInit: true});
	}
}


function getInstance(){

}

function generateMarketList(){

	// Select random animals to add to the market list
	let aniToAdd = v.marketMaxCapacity - v.marketCurrentCount;

	if (aniToAdd > 0){			
														// If there are empty slots in the market
		for(i = 0; i < aniToAdd; i++){

			let randomElement = Math.floor(Math.random() * baseAnimalList.length); 					// Select a random number in the base animal list
			let currentAnimal = baseAnimalList[randomElement].getInstance();						// Initialise the random animal
			availableList.push(currentAnimal);														// Add the animal to the list of available animal

			currentAnimal.aniId = availableList.length -1;											// Initialise the Id
			currentAnimal.aniPlace = 'Market';														// Change the place to market

			v.marketCurrentCount = v.marketCurrentCount + 1;										// Add 1 to the number of animals in the market

		} 
	}
};

function buyAnimal(){
	
}


function moveAnimal(id, newPlace, newPlaceId, isInit){

	if(id != null){
		let currentAnimal = availableList[id];											//On initialise l'animal

		if(currentAnimal.aniCost >= v.money && newPlace == 'holdingPen'){				//Si l'animal est acheté depuis le marché, on vérifie qu'on a assez d'argent
			updateLogs("Not enough money");												//Si ça n'est pas le cas, on arrête la fonction et on log le problème
			return
		}

		currentAnimal.aniPlace = newPlace;												//On met à jour la nouvelle place de l'animal

		let costTxt = '';																//Variable vide destinée à récupérer le coût s'il doit être affiché
		if(newPlace == 'enclosure'){
			if(isThereRoom(newPlaceId) == false){										//Si le nouvel emplacement est un enclos, on vérifie qu'il a de la place
				repopulateDropdownList													//Si ça n'est pas le cas, on arrête la fonction
			} else {
				newPlace = newPlace + newPlaceId;										//Si la destination est un enclos et qu'il a de la place, on prépare son nom
				currentAnimal.aniPlaceId = newPlaceId;									//On met à jour l'id de l'enclos dans l'objet animal
			}
		} else if(newPlace == 'Market'){												
			costTxt = '<br>Cost : ' + currentAnimal.aniCost;							//Si la destination est le marché, on ajout le cout au span global.
		}

		if(isInit == false){
			let divToRemove = document.getElementById("Div" + currentAnimal.aniId);		//Si on n'est pas à l'initialisation, on supprime le Div de l'emplacement 
			divToRemove.remove();														//précédent de l'animal
		}

		let newDiv = document.createElement("div");
		newDiv.id = "Div" + currentAnimal.aniId;						
		newDiv.classList.add('marketDivCss');	

		let newSpan = document.createElement("span");
		let str = currentAnimal.aniName + '<br>' + 'Size : ' + currentAnimal.aniSize +
			'<br>Attractivity : ' + currentAnimal.aniAttract +
			costTxt;
		newSpan.insertAdjacentHTML( 'beforeend', str );

		newDiv.appendChild(newSpan);

		if(newPlace == 'holdingPen'){
			holdingPenList.push(currentAnimal);
			v.money = v.money - currentAnimal.aniCost;
		} else if (newPlace == 'Market'){
			let btBuyAni = document.createElement("button");
			btBuyAni.id = "Bt" + currentAnimal.aniId;
			btBuyAni.classList.add('btBuyAni');
			btBuyAni.textContent = "Buy";
			btBuyAni.addEventListener("click", function () {moveAnimal(currentAnimal.aniId, 'holdingPen', null, false);});
			newDiv.appendChild(btBuyAni);
		}

		let node = document.getElementById(newPlace);
		node.appendChild(newDiv);
		repopulateDropdownList();	
	}
};


function initializeAni() {
	for (let ani of availableList){
		moveAnimal(ani.aniId, ani.aniPlace, ani.aniEncId, true);
	}	
}


var loadedAniList = [];
var baseAnimalList = [];	// List of all animals from the initial pool, 1 animal of each type only
var availableList = [];		// List of all animals bought or buyable. Used mainly to attribute unique ID
var holdingPenList = [];	// List of all animals currently in the holding pen



const fox = new Animals({
	aniName: "Fox",
	aniFood: "Carnivora",
	aniSize: "Small",
	aniAttract: 3});

const sheep = new Animals({
	aniName: "Sheep",
	aniFood: "Herbivora",
	aniSize: "Medium",
	aniAttract: 1});

const horse = new Animals({
	aniName: "Horse",
	aniFood: "Herbivora",
	aniSize: "Medium",
	aniAttract: 1});

const deer = new Animals({
	aniName: "Deer",
	aniFood: "Herbivora",
	aniSize: "Medium",
	aniAttract: 2});

const wolf = new Animals({
	aniName: "Wolf",
	aniFood: "Carnivora",
	aniSize: "Medium",
	aniAttract: 4});

const cow = new Animals({
	aniName: "Cow",
	aniFood: "Herbivora",
	aniSize: "Medium",
	aniAttract: 1});

const blackBear = new Animals({
	aniName: "Black bear",
	aniFood: "Carnivora",
	aniSize: "Medium",
	aniAttract: 6});
